# NexUnit Technical Analysis Report

## 1. High-Level System Architecture

### Project Overview
NexUnit is an AI-powered cybersecurity automation platform designed to facilitate penetration testing, bug bounty hunting, and security research. It operates as a multi-agent system where a central server (`nexunit_server.py`) orchestrates various security tools and provides an API for AI agents (via `nexunit_mcp.py`) to interact with.

### Main Components
1.  **NexUnit Server (`nexunit_server.py`)**: The core engine that manages tool execution, process lifecycle, intelligent decision-making, and provides a REST API. It includes a "Modern Visual Engine" for CLI output and a "Intelligent Decision Engine" for automated reasoning.
2.  **NexUnit MCP Client (`nexunit_mcp.py`)**: A Model Context Protocol (MCP) client that connects to the server. It exposes over 150 security tools (Nmap, Gobuster, etc.) as functions that can be called by AI agents (like Claude or GPT).
3.  **NexUnit AI Package (`nexunit_ai/`)**: The modular backend containing core logic, execution management, API routes, and workflows.
    *   **Core**: Intelligence and decision-making modules.
    *   **Execution**: Process management and tool execution wrappers.
    *   **API**: Flask route definitions.
    *   **Workflows**: Pre-defined security workflows (e.g., Bug Bounty, CTF).

### Communication Flow
*   **User/AI Agent** -> **MCP Client** (via FastMCP) -> **NexUnit Server** (via HTTP REST API) -> **Security Tools** (Subprocesses).
*   The server manages the state, executes commands asynchronously, and returns results/telemetry to the client.

### Technologies Used
*   **Python 3.8+**: Core language.
*   **Flask**: Web server framework for the API.
*   **FastMCP**: Protocol for AI agent integration.
*   **Selenium**: For browser-based automation (Headless Chrome).
*   **Subprocess/Psutil**: For managing external security tools.
*   **Mermaid**: For architecture visualization in documentation.

## 2. Module-by-Module Breakdown

### Root Directory
*   **`nexunit_server.py`**: The main entry point for the server. It initializes the Flask app, configures the API, and starts the server. It also contains the `ModernVisualEngine` class for rich CLI output.
*   **`nexunit_mcp.py`**: The MCP client entry point. It connects to the server and exposes tools to AI agents. It includes the `NexUnitClient` class for API communication and `setup_mcp_server` to register tools.
*   **`config.py`**: Configuration settings for the application.

### `nexunit_ai` Package
*   **`core/`**: Contains the intelligence of the system.
    *   **`decision_engine.py`**: Implements `IntelligentDecisionEngine`. It analyzes targets (`TargetProfile`), determines technology stacks (`TechnologyStack`), and builds attack chains (`AttackChain`). It uses heuristics to select tools and optimize parameters.
    *   **`visual_engine.py`**: Handles the visual presentation of data, likely used by the server for CLI output.
*   **`execution/`**: Manages the running of tools.
    *   **`process_manager.py`**: `EnhancedProcessManager` handles asynchronous command execution, resource monitoring, and auto-scaling of the process pool.
    *   **`process_pool.py`**: Manages a pool of worker processes to execute commands in parallel.
    *   **`command_executor.py`**: Wrapper for executing individual commands.
    *   **`monitoring.py`**: Monitors system resources (CPU, RAM) to prevent overload.
    *   **`cache.py`**: Caching mechanism to avoid re-running identical commands.
*   **`api/`**: Defines the REST API endpoints.
    *   **`core_routes.py`**: Basic system routes (health check, etc.).
    *   **`intelligence_routes.py`**: Endpoints for the decision engine (analyze target, select tools).
    *   **`process_routes.py`**: Endpoints for managing processes (list, terminate).
    *   **`workflow_routes.py`**: Endpoints for triggering complex workflows.
*   **`workflows/`**: Contains pre-defined security workflows.
    *   **`bugbounty.py`**: Workflows tailored for bug bounty hunting (recon, scanning).
    *   **`ctf.py`**: Workflows for Capture The Flag challenges.
*   **`handlers/`**: Error handling and recovery logic.
    *   **`error_handler.py`**: Centralized error management.

## 3. Execution Flow (Step-by-Step)

### 1. Startup
1.  User starts `nexunit_server.py`.
2.  Server initializes `Flask` app, `EnhancedProcessManager`, and `IntelligentDecisionEngine`.
3.  Server starts listening on the configured port (default 8888).
4.  User starts `nexunit_mcp.py` (or connects via an AI agent).
5.  MCP client connects to the server's `/health` endpoint to verify connectivity.
6.  MCP client registers tools with the AI agent platform (e.g., Claude Desktop).

### 2. Tool Execution Request
1.  AI Agent (e.g., Claude) calls a tool function (e.g., `nmap_scan`).
2.  `nexunit_mcp.py` receives the call and sends a POST request to `http://localhost:8888/api/command` (or specific tool endpoint).
3.  Server receives the request.
4.  `EnhancedProcessManager` checks the cache. If cached, returns result immediately.
5.  If not cached, it adds the command to the `ProcessPool`.
6.  A worker process executes the command (e.g., `nmap -sV ...`).
7.  Output is captured and streamed/logged.
8.  Upon completion, the result is stored in cache and returned to the API response.
9.  MCP client receives the result and passes it back to the AI agent.

### 3. Intelligent Analysis Request
1.  AI Agent calls `analyze_target`.
2.  Request goes to `intelligence_routes.py`.
3.  `IntelligentDecisionEngine` performs passive analysis (DNS resolution, tech detection).
4.  It creates a `TargetProfile` and calculates the attack surface score.
5.  It generates a recommended `AttackChain`.
6.  The profile and recommendations are returned to the agent.

## 4. Code Quality & Patterns

### Design Patterns
*   **Facade Pattern**: The `NexUnitClient` provides a simplified interface to the complex server API.
*   **Command Pattern**: Tool executions are encapsulated as commands managed by the `ProcessManager`.
*   **Strategy Pattern**: `IntelligentDecisionEngine` likely uses different strategies for different target types.
*   **Singleton Pattern**: The `ProcessManager` and `DecisionEngine` are likely instantiated once and shared (though Python modules act as singletons naturally).

### Observations
*   **Monolithic Files**: `nexunit_server.py` and `nexunit_mcp.py` are very large, mixing configuration, initialization, and logic. This makes maintenance harder.
*   **Hardcoded Paths/Values**: Some tools seem to have default paths (e.g., wordlists) which might not exist on all systems.
*   **Error Handling**: There is a dedicated `handlers` module, which is good.
*   **Type Hinting**: Extensive use of `typing` module, which is excellent for readability and tooling.

## 5. Performance & Security Review

### Performance
*   **Async Execution**: Heavy use of `asyncio` and `threading` allows for non-blocking operations, which is crucial for a tool that runs long scans.
*   **Caching**: The `cache.py` module prevents redundant scans, saving significant time.
*   **Resource Monitoring**: `monitoring.py` helps avoid crashing the host system by limiting concurrency based on load.

### Security
*   **Command Injection**: The system executes shell commands. While `subprocess` is used, great care must be taken to sanitize inputs. The `nexunit_mcp.py` seems to construct command strings. If the AI agent can inject arbitrary shell characters, it could be a risk (though the user is likely the one controlling the agent).
*   **No Authentication**: The default server runs on localhost without auth. If exposed to a network, it allows RCE.
*   **Privileges**: Some tools (like `nmap` SYN scan) require root. The server might need to run as root, which increases risk.

## 6. Recommendations

### Immediate Improvements
1.  **Refactor Monoliths**: Split `nexunit_server.py` and `nexunit_mcp.py` into smaller, focused modules.
2.  **Security Hardening**: Add an API key mechanism for the server to prevent unauthorized local/network access.
3.  **Input Sanitization**: Ensure all command arguments are strictly validated or properly escaped before passing to `subprocess`.

### Future Roadmap
1.  **Distributed Agents**: Allow multiple MCP clients to connect to a central server, or multiple servers to coordinate.
2.  **Database Integration**: Move from in-memory/file-based caching to a proper database (SQLite/PostgreSQL) for persistence.
3.  **Web UI**: Build a React/Next.js frontend to visualize the "Modern Visual Engine" data in a browser.

## 7. Diagrams

### A. System Architecture Diagram

```mermaid
graph TD
    User[User / AI Agent] -->|MCP Protocol| MCP[NexUnit MCP Client]
    MCP -->|HTTP REST API| Server[NexUnit Server]
    
    subgraph "NexUnit Server"
        API[API Layer]
        DE[Intelligent Decision Engine]
        PM[Enhanced Process Manager]
        VE[Modern Visual Engine]
        
        API --> DE
        API --> PM
        DE --> PM
        PM --> VE
    end
    
    subgraph "Execution Environment"
        Pool[Process Pool]
        Tool1[Nmap]
        Tool2[Gobuster]
        Tool3[Nuclei]
        
        PM --> Pool
        Pool --> Tool1
        Pool --> Tool2
        Pool --> Tool3
    end
    
    Server -->|Logs/Telemetry| LogFile[nexunit.log]
```

### B. Data/Request Flow Diagram

```mermaid
sequenceDiagram
    participant Agent as AI Agent
    participant MCP as MCP Client
    participant API as Server API
    participant PM as Process Manager
    participant Tool as Security Tool
    
    Agent->>MCP: Call Tool (e.g., nmap_scan)
    MCP->>API: POST /api/command
    API->>PM: Execute Command
    PM->>PM: Check Cache
    alt Cache Hit
        PM-->>API: Return Cached Result
    else Cache Miss
        PM->>Tool: Spawn Process
        Tool-->>PM: Stream Output
        PM-->>API: Return Result
    end
    API-->>MCP: JSON Response
    MCP-->>Agent: Tool Output
```

### C. Module/Folder Structure Diagram

```mermaid
graph TD
    Root[nexunit-ai]
    Root --> Server[nexunit_server.py]
    Root --> MCP[nexunit_mcp.py]
    Root --> Pkg[nexunit_ai/]
    
    Pkg --> Core[core/]
    Pkg --> Exec[execution/]
    Pkg --> API[api/]
    Pkg --> Work[workflows/]
    Pkg --> Handlers[handlers/]
    
    Core --> DE[decision_engine.py]
    Core --> VE[visual_engine.py]
    
    Exec --> PM[process_manager.py]
    Exec --> PP[process_pool.py]
    Exec --> Mon[monitoring.py]
    
    API --> Routes[routes definitions]
    
    Work --> Bug[bugbounty.py]
    Work --> CTF[ctf.py]
```

### D. Component Interaction Diagram

```mermaid
classDiagram
    class NexUnitServer {
        +start()
        +register_routes()
    }
    class IntelligentDecisionEngine {
        +analyze_target()
        +create_attack_chain()
    }
    class EnhancedProcessManager {
        +execute_command_async()
        +monitor_resources()
    }
    class ModernVisualEngine {
        +render_dashboard()
        +format_output()
    }
    
    NexUnitServer --> IntelligentDecisionEngine : Uses
    NexUnitServer --> EnhancedProcessManager : Uses
    NexUnitServer --> ModernVisualEngine : Uses
    IntelligentDecisionEngine ..> EnhancedProcessManager : Recommends Tools
```

### E. Workflow Diagram (Bug Bounty)

```mermaid
stateDiagram-v2
    [*] --> TargetAnalysis
    TargetAnalysis --> TechDetection
    TechDetection --> ToolSelection
    
    state "Reconnaissance" as Recon {
        SubdomainEnum --> PortScan
        PortScan --> ServiceDiscovery
    }
    
    ToolSelection --> Recon
    
    state "Vulnerability Scanning" as Vuln {
        NucleiScan --> WebFuzzing
        WebFuzzing --> ParamAnalysis
    }
    
    Recon --> Vuln
    Vuln --> Reporting
    Reporting --> [*]
```

## 8. Final Summary

### System Summary
NexUnit is a sophisticated, AI-first security automation platform. It successfully bridges the gap between high-level AI reasoning (via LLMs) and low-level security tool execution. Its architecture is robust, featuring a dedicated server for state management, an intelligent engine for decision-making, and an MCP interface for seamless integration with modern AI coding assistants.

### Strongest Parts
1.  **MCP Integration**: The implementation of the Model Context Protocol is comprehensive, exposing a vast array of tools to AI agents.
2.  **Intelligent Decision Engine**: The logic to analyze a target and dynamically select tools/parameters is a significant value-add over simple script wrappers.
3.  **Visual Engine**: The effort put into CLI aesthetics (colors, progress bars, dashboards) makes it highly usable for human operators monitoring the AI.

### Weakest Parts
1.  **Monolithic Entry Points**: The `nexunit_server.py` and `nexunit_mcp.py` files are overly large and contain mixed responsibilities.
2.  **Security Model**: Running as a local server with no authentication is risky if the machine is exposed to a network.
3.  **Dependency Management**: Reliance on a huge list of external binary tools (nmap, etc.) makes setup fragile.

### Recommendations for Next Steps
1.  **Dockerization**: Create a Dockerfile to bundle all external tools and the Python environment, ensuring a consistent runtime.
2.  **API Authentication**: Implement API keys or JWT to secure the server endpoints.
3.  **Refactoring**: Break down the monolithic files into smaller, domain-specific modules within the `nexunit_ai` package.

### Professional-Grade Transformation
To turn this into a commercial-grade tool, focus on **reliability** and **scalability**. Move from local process execution to a distributed worker queue (e.g., Celery + Redis). Implement a persistent database for results and history. Finally, build a web-based dashboard to replace or augment the CLI visual engine, allowing for collaborative engagements.
