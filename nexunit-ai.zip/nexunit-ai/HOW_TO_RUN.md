# NexUnit AI - How to Run

## 🚀 Quick Start

### 1. Install Dependencies

```bash
# Navigate to project directory
cd nexunit-ai

# Create virtual environment (recommended)
python3 -m venv nexunit_env
source nexunit_env/bin/activate  # Linux/Mac
# nexunit_env\Scripts\activate   # Windows

# Install Python dependencies
pip3 install -r requirements.txt
```

### 2. Start the Server

```bash
# Option 1: Run modular server (recommended)
python3 -m nexunit_ai.server

# Option 2: Run with custom port
python3 -m nexunit_ai.server --port 9999

# Option 3: Run with debug mode
python3 -m nexunit_ai.server --debug

# Option 4: Use legacy server (still works)
python3 nexunit_server.py
```

### 3. Verify Server is Running

```bash
# Check health endpoint
curl http://localhost:8888/health

# Or open in browser
# http://localhost:8888/health
```

## 📡 MCP Client Setup

### For Claude Desktop / Cursor

1. Edit your MCP configuration file:
   - **Claude Desktop**: `~/.config/Claude/claude_desktop_config.json`
   - **Cursor**: `.cursor/mcp.json` or settings

2. Add NexUnit configuration:

```json
{
  "mcpServers": {
    "nexunit-ai": {
      "command": "python3",
      "args": [
        "/path/to/nexunit-ai/nexunit_mcp.py",
        "--server",
        "http://localhost:8888"
      ],
      "description": "NexUnit AI v6.0 - Advanced Cybersecurity Automation Platform",
      "timeout": 300,
      "alwaysAllow": []
    }
  }
}
```

3. Replace `/path/to/nexunit-ai/` with your actual project path

4. Restart Claude Desktop or Cursor

### Verify MCP Connection

The MCP client will automatically connect to the server on startup. Check logs for:
```
✅ Successfully connected to NexUnit AI API Server
```

## 🔧 Configuration

### Environment Variables

```bash
# API Configuration
export NEXUNIT_PORT=8888          # Server port (default: 8888)
export NEXUNIT_HOST=127.0.0.1     # Server host (default: 127.0.0.1)

# Command Execution
export NEXUNIT_TIMEOUT=300         # Command timeout in seconds (default: 300)

# Cache Configuration
export NEXUNIT_CACHE_SIZE=1000     # Cache size (default: 1000)
export NEXUNIT_CACHE_TTL=3600      # Cache TTL in seconds (default: 3600)

# Logging
export NEXUNIT_LOG_FILE=nexunit.log
export NEXUNIT_LOG_LEVEL=INFO      # DEBUG, INFO, WARNING, ERROR

# Debug Mode
export NEXUNIT_DEBUG=true
```

### Configuration File

Edit `nexunit_ai/config.py` to change default settings.

## 📝 Usage Examples

### Using the API Directly

```bash
# Health check
curl http://localhost:8888/health

# Execute a command
curl -X POST http://localhost:8888/api/command \
  -H "Content-Type: application/json" \
  -d '{"command": "nmap -sV example.com", "use_cache": true}'

# Analyze a target
curl -X POST http://localhost:8888/api/intelligence/analyze-target \
  -H "Content-Type: application/json" \
  -d '{"target": "https://example.com", "analysis_type": "comprehensive"}'
```

### Using Python Modules

```python
# Import modules
from nexunit_ai.core.visual_engine import ModernVisualEngine
from nexunit_ai.core.decision_engine import IntelligentDecisionEngine
from nexunit_ai.execution import EnhancedProcessManager

# Use Visual Engine
banner = ModernVisualEngine.create_banner("127.0.0.1", 8888)
print(banner)

# Use Decision Engine
engine = IntelligentDecisionEngine()
profile = engine.analyze_target("https://example.com")
tools = engine.select_optimal_tools(profile)
print(f"Selected tools: {tools}")

# Use Process Manager
pm = EnhancedProcessManager()
result = pm.execute_command_async("nmap -sV example.com")
```

### Using MCP Tools (via AI Agent)

Once connected to Claude/Cursor, you can use tools like:

```
"Run an Nmap scan on example.com"
"Perform a comprehensive security assessment of target.com"
"Execute a bug bounty reconnaissance workflow for example.com"
```

## 🛠️ Troubleshooting

### Server Won't Start

```bash
# Check if port is already in use
netstat -tlnp | grep 8888
# or
lsof -i :8888

# Kill process if needed
kill -9 <PID>

# Try different port
python3 -m nexunit_ai.server --port 9999
```

### MCP Connection Failed

```bash
# 1. Verify server is running
curl http://localhost:8888/health

# 2. Check MCP configuration path
# Make sure path to nexunit_mcp.py is correct

# 3. Check server URL in MCP config
# Should match NEXUNIT_HOST and NEXUNIT_PORT

# 4. Check logs
tail -f nexunit.log
```

### Import Errors

```bash
# Make sure you're in the project directory
cd /path/to/nexunit-ai

# Verify Python can find the package
python3 -c "import nexunit_ai; print('✅ Package found')"

# Install in development mode (if needed)
pip3 install -e .
```

### Missing Security Tools

```bash
# Check if tools are installed
which nmap gobuster nuclei

# Install missing tools (example for Kali Linux)
sudo apt update
sudo apt install nmap gobuster nuclei nikto sqlmap

# Or install from their official sources
```

## 📋 Prerequisites

### Required Python Packages
- Python 3.8+
- All packages in `requirements.txt`

### Optional Security Tools
- 150+ security tools (nmap, gobuster, nuclei, etc.)
- Install as needed for your use case

### System Requirements
- Linux/macOS/Windows
- 2GB+ RAM recommended
- Network access for API calls

## 🎯 Common Commands

```bash
# Start server
python3 -m nexunit_ai.server

# Start with debug
python3 -m nexunit_ai.server --debug

# Start on custom port
python3 -m nexunit_ai.server --port 9999

# Check server status
curl http://localhost:8888/health

# View logs
tail -f nexunit.log

# Test imports
python3 -c "from nexunit_ai.core import ModernVisualEngine; print('✅ OK')"
```

## 📚 Next Steps

1. **Start the server**: `python3 -m nexunit_ai.server`
2. **Configure MCP client** for your AI agent
3. **Test with a simple command**: Use the health endpoint
4. **Try MCP tools**: Ask your AI agent to use NexUnit tools
5. **Explore modules**: Check out the modular structure

## 🆘 Need Help?

- Check `nexunit.log` for error messages
- Verify all dependencies are installed
- Ensure security tools are available (if using tool endpoints)
- Check firewall settings if connection fails

---

**That's it! You're ready to use NexUnit AI! 🚀**

