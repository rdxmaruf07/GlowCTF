#!/usr/bin/env python3
"""
NexUnit AI - Modular Server Entry Point

Main Flask application server using modular components
"""

import logging
import sys
from flask import Flask

# Import modular components
from nexunit_ai.config import API_PORT, API_HOST, DEBUG_MODE, LOG_FILE
from nexunit_ai.core.visual_engine import ModernVisualEngine

# Configure logging
try:
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
            logging.FileHandler(LOG_FILE)
        ]
    )
except PermissionError:
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[logging.StreamHandler(sys.stdout)]
    )

logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.config['JSON_SORT_KEYS'] = False

# Import and initialize core components
from nexunit_ai.core.decision_engine import IntelligentDecisionEngine
from nexunit_ai.handlers.error_handler import IntelligentErrorHandler, GracefulDegradation

# Global instances
decision_engine = IntelligentDecisionEngine()
error_handler = IntelligentErrorHandler()
degradation_manager = GracefulDegradation()

# Register API route blueprints
from nexunit_ai.api import core_routes, process_routes, intelligence_routes, workflow_routes

app.register_blueprint(core_routes.core_bp)
app.register_blueprint(process_routes.process_bp, url_prefix='/api/processes')
app.register_blueprint(intelligence_routes.intelligence_bp, url_prefix='/api/intelligence')
app.register_blueprint(workflow_routes.workflow_bp, url_prefix='/api/bugbounty')

@app.route("/", methods=["GET"])
def index():
    """Root endpoint"""
    return {
        "service": "NexUnit AI",
        "version": "6.0.0",
        "status": "running",
        "endpoints": {
            "health": "/health",
            "api": "/api/*"
        }
    }

def create_app():
    """Factory function to create Flask app"""
    return app

def main():
    """Main entry point"""
    # Display banner
    banner = ModernVisualEngine.create_banner(API_HOST, API_PORT)
    print(banner)
    
    logger.info(f"🚀 Starting NexUnit AI Server")
    logger.info(f"🌐 Listening on {API_HOST}:{API_PORT}")
    logger.info(f"🔧 Debug Mode: {DEBUG_MODE}")
    
    # Start Flask server
    app.run(
        host=API_HOST,
        port=API_PORT,
        debug=DEBUG_MODE
    )

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="NexUnit AI Server")
    parser.add_argument("--debug", action="store_true", help="Enable debug mode")
    parser.add_argument("--port", type=int, default=API_PORT, help=f"Port (default: {API_PORT})")
    args = parser.parse_args()
    
    if args.debug:
        DEBUG_MODE = True
        logger.setLevel(logging.DEBUG)
    
    if args.port != API_PORT:
        API_PORT = args.port
    
    main()

