"""
NexUnit AI - API Routes Modules
"""

# Routes are registered in server.py
# Import here for easy access if needed

__all__ = [
    'core_routes',
    'process_routes',
    'intelligence_routes',
    'workflow_routes'
]

