"""
NexUnit AI - Configuration Management
"""

import os
from typing import Optional

# API Configuration
API_PORT = int(os.environ.get('NEXUNIT_PORT', 8888))
API_HOST = os.environ.get('NEXUNIT_HOST', '127.0.0.1')

# Command Execution Configuration
COMMAND_TIMEOUT = int(os.environ.get('NEXUNIT_TIMEOUT', 300))  # 5 minutes default
DEBUG_MODE = os.environ.get('NEXUNIT_DEBUG', 'False').lower() == 'true'

# Cache Configuration
CACHE_SIZE = int(os.environ.get('NEXUNIT_CACHE_SIZE', 1000))
CACHE_TTL = int(os.environ.get('NEXUNIT_CACHE_TTL', 3600))  # 1 hour default

# Logging Configuration
LOG_FILE = os.environ.get('NEXUNIT_LOG_FILE', 'nexunit.log')
LOG_LEVEL = os.environ.get('NEXUNIT_LOG_LEVEL', 'INFO')

def get_config() -> dict:
    """Get all configuration as a dictionary"""
    return {
        'api_port': API_PORT,
        'api_host': API_HOST,
        'command_timeout': COMMAND_TIMEOUT,
        'debug_mode': DEBUG_MODE,
        'cache_size': CACHE_SIZE,
        'cache_ttl': CACHE_TTL,
        'log_file': LOG_FILE,
        'log_level': LOG_LEVEL
    }

