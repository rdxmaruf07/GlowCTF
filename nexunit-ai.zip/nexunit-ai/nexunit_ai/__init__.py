"""
NexUnit AI - Advanced Penetration Testing Framework

Modular AI-powered penetration testing framework with 150+ security tools
"""

__version__ = "6.0.0"
__author__ = "NexUnit Team"

# Core modules
from nexunit_ai.core.visual_engine import ModernVisualEngine
from nexunit_ai.core.decision_engine import (
    IntelligentDecisionEngine,
    TargetProfile,
    TargetType,
    TechnologyStack,
    AttackChain,
    AttackStep
)

# Handler modules
from nexunit_ai.handlers.error_handler import (
    IntelligentErrorHandler,
    ErrorType,
    RecoveryAction,
    GracefulDegradation
)

# Config
from nexunit_ai.config import API_PORT, API_HOST, get_config

__all__ = [
    # Core
    'ModernVisualEngine',
    'IntelligentDecisionEngine',
    'TargetProfile',
    'TargetType',
    'TechnologyStack',
    'AttackChain',
    'AttackStep',
    # Handlers
    'IntelligentErrorHandler',
    'ErrorType',
    'RecoveryAction',
    'GracefulDegradation',
    # Config
    'API_PORT',
    'API_HOST',
    'get_config',
]

